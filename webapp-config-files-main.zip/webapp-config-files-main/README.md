* This repository contains the configuration files like manifestation yaml file for web app deployment project.
* When the files of this repo is updated, GitOps tool like ArgoCD will automatically sync changes to the deployed application.
